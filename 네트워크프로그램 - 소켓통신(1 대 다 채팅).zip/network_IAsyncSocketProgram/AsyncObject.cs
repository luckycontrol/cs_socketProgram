﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;

namespace network_IAsyncSocketProgram
{
    class AsyncObject
    {
        public byte[] buffer;
        public Socket workingSocket;
        public readonly int bufferSize;

        public AsyncObject(int buffersize)
        {
            bufferSize = buffersize;
            buffer = new byte[bufferSize];
        }

        public void clearBuffer()
        {
            Array.Clear(buffer, 0, bufferSize);
        }
    }
}
